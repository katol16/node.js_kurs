// console.log('Starting app.js');

// wymagamy modułu fs
// To oznacza, ze wszystkie funkcję dostepne na tym module, będziemy mieli dostępne w stałej fs
const fs = require('fs');

// kolejny moduł 'os'
const os = require('os');

// 3rd part modules (lodash)
const _ = require('lodash');

// 3rd part modules (yargs)
const yargs = require('yargs');

// isString - to funkcja z pakietu lodash (sprawdz czy coś ejst stringiem)
// console.log(_.isString(true));
// console.log(_.isString('karol'));

// teraz będziemy wyagać pliku, który sami stworzylismy
// i będziemy mogli korzystać z funkcji zapisanych w tym pliku
const notes = require('./notes.js');

// użyjemy funkcji userInfo, która pokaże dane o użytkowniku
// podajemy relatywną ścieżkę ('./') - to kieruję na obecną ścieżkę
	// var user = os.userInfo();
	// console.log(user);
// w powyższej consoli, zoabczysz ,ze userInfo(), zwróci obiekt o uzytkowniku,
// do którego mamy dostęp (np. user.username)

// Teraz użyjemy jednej z funckji modułu "fs"
// funkcja appendFile, przyjmuję dwa argumenty ('nazwa_pliku', 'tekxt ktory dodamy do pliku')
// fs.appendFileSync('greetings.txt',`Hello ${user.username}! You are ${notes.age}!`);
// Powyżej użyliśmy konkatenacji z ES6

// funckja addNote z notes.js(naszego pliku)
var res = notes.addNote();
console.log(res);

// challenge
// var sum = notes.add(9,-2);
// console.log(sum);

// USING 3rd PARTY MODULES
// w consoli instalujemy npm
// w consoli sprawdzamy czy ejst zainstalowany "npm -v"
// dalej: "npm init" - i odpowiadamy na pytania
// w pliku package.json - mamy informacje na temat zainstalowanych 3rd part modules

// na stronie npmjs.com - możemy poszukać pakietów i poczytac o nich

// zainstalujemy pakiet "lodash"
// npm install lodash --save
// możesz sprawdzic w package.json, ze lodash jest zaisntalowany

var filteredArray = _.uniq(['Andrew',1,'Andrew',1,2,3,4]);
// usunie zdyplikowane elementy tablicy
console.log(filteredArray);

// instalacja nodemon
// npm install nodemon -g

// Getting input from user & Simplified Input with Yargs
const argv = yargs.argv;

// process.argv, to coś jak argument w js, jeśli w consoli wpiszesz node app.js chuj, to chuj będzie nowym argmentem dostepnym w process.argv
// [2] to tutaj indeks naszzego argumentu

// var command = process.argv[2];
// poniżej to samo, ale lepszy zapis
var command = argv._[0];

// teraz jeśli w konsoli wpiszemy "node app.js tekst", to tekst wyświetli się w konsoli
console.log('Command: ', command);


console.log('Process: ', process.argv);

// zobaczmy jak wygląda Yargs
console.log('Yargs', argv);


if (command === 'add') {
	// console.log('Adding new notes');
	var note = notes.addNote(argv.title, argv.body);

	if (note) {
		console.log('Note Created');
		notes.logNote(note);
	} else {
		console.log('Note title taken');
	}

} else if (command === 'list') {
	// console.log('Listing all notes');
	var allNotes = notes.getAll();
	console.log(`Printing ${allNotes.length} note(s).`);
	allNotes.forEach((note) => notes.logNote(note));

} else if (command === 'read') {
	// console.log('reading notes');
	var note = notes.getNote(argv.title);	
		notes.logNote(note);
	if (note) {
		console.log('Note found');
	} else {
		console.log('Note not found');
	}

} else if (command === 'remove') {
	// console.log('removing notes');
	var noteRemoved = notes.removeNote(argv.title);
	// wyświetlimy informację na temat usunięcia notatki
	var message = noteRemoved ? 'Note was removed' : 'Note not found';
	console.log(message);	

} else {
	console.log('comment not recognize');
}

// Instalacja frameworka Yargs w naszej sciezce
// npm install yargs@4.7.1 --save
// Yargs generalnie aprsuję stringi w łatwy i intuicyjny sposób